"""
Initialize Momentum Module.
"""
from mlfinlab.online_portfolio_selection.eg import EG
from mlfinlab.online_portfolio_selection.ftl import FTL
from mlfinlab.online_portfolio_selection.ftrl import FTRL
