"""
Functionality relating to the ETF trick and stitching futures contracts together.
"""

from mlfinlab.multi_product.etf_trick import ETFTrick, get_futures_roll_series
